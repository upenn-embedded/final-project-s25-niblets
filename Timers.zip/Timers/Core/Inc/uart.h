/*
 * uart.h
 *
 *  Created on: Mar 11, 2025
 *      Author: banele
 */

#ifndef UART_H_
#define UART_H_
#include <stm32f446xx.h>
void uart_init(void);
#endif /* UART_H_ */
