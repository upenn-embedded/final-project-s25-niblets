#include "exti.h"

#define GPIOCEN         (1U<<2)
#define SYSCFGEN        (1U<<14)


void pc13_exti_init(void)
{
    /*Disable global interrupts*/
    __disable_irq();
    /*Enable clock access for GPIOC*/
    RCC->AHB1ENR |=GPIOCEN;
    /*Set PC13 as input*/
    GPIOC->MODER &=~(1U<<26);
    GPIOC->MODER &=~(1U<<27);
    /*Enable clock access to SYSCFG*/
    RCC->APB2ENR |=SYSCFGEN;
    /*Select PORTC for EXTI13*/
    SYSCFG->EXTICR[3] |=(1U<<5);
    /*Unmask EXTI13*/
    EXTI->IMR |=(1U<<13);
    /*Select falling edge trigger*/
    EXTI->FTSR |=(1U<<13);
    /*Enable EXTI13 line in NVIC*/
    NVIC_EnableIRQ(EXTI15_10_IRQn);
    /*Enable global interrupts*/
    __enable_irq();
}

void pa1_exti_init(void)
{
    __disable_irq();
    // 1) Enable GPIOA clock
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
    // 2) Set PA1 as input (MODER1 = 00)
    GPIOA->MODER &= ~(1U << 2);
    GPIOA->MODER &= ~(1U << 3);
    // 3) Enable SYSCFG clock
    RCC->APB2ENR |= RCC_APB2ENR_SYSCFGEN;
    // 4) Select PA for EXTI1 (EXTICR[0], bits [7:4] = 0)
    SYSCFG->EXTICR[0] &= ~(0xF << 4);
    SYSCFG->EXTICR[0] |=  (0   << 4);
    // 5) Unmask EXTI1 and configure falling‑edge trigger
    EXTI->IMR  |= (1U << 1);
    EXTI->FTSR &= ~(1U << 1);  // disable falling
    EXTI->RTSR |=  (1U << 1);  // enable rising
    // 6) Enable EXTI1 IRQ
    NVIC_SetPriority(EXTI1_IRQn, 1);
    NVIC_EnableIRQ(EXTI1_IRQn);
    __enable_irq();
}

// EXTI on PA2
void pa2_exti_init(void)
{
    __disable_irq();
    // 1) Enable GPIOA clock
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
    // 2) Set PA2 as input (MODER2 = 00)
    GPIOA->MODER &= ~(1U << 4);
    GPIOA->MODER &= ~(1U << 5);
    // 3) Enable SYSCFG clock
    RCC->APB2ENR |= RCC_APB2ENR_SYSCFGEN;
    // 4) Select PA for EXTI2 (EXTICR[0], bits [11:8] = 0)
    SYSCFG->EXTICR[0] &= ~(0xF << 8);
    SYSCFG->EXTICR[0] |=  (0   << 8);
    // 5) Unmask EXTI2 and configure falling‑edge trigger
    EXTI->IMR  |= (1U << 2);
    EXTI->FTSR &= ~(1U << 2);  // disable falling
       EXTI->RTSR |=  (1U << 2);
    // 6) Enable EXTI2 IRQ
    NVIC_SetPriority(EXTI2_IRQn, 1);
    NVIC_EnableIRQ(EXTI2_IRQn);
    __enable_irq();
}

// EXTI on PA10
void pa10_exti_init(void)
{
    __disable_irq();
    // 1) Enable GPIOA clock
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
    // 2) Set PA10 as input (MODER10 = 00)
    GPIOA->MODER &= ~(1U << 20);
    GPIOA->MODER &= ~(1U << 21);
    // 3) Enable SYSCFG clock
    RCC->APB2ENR |= RCC_APB2ENR_SYSCFGEN;
    // 4) Select PA for EXTI10 (EXTICR[2], bits [11:8] = 0)
    SYSCFG->EXTICR[2] &= ~(0xF << 8);
    SYSCFG->EXTICR[2] |=  (0   << 8);
    // 5) Unmask EXTI10 and configure falling‑edge trigger
    EXTI->IMR  |= (1U << 10);
    EXTI->FTSR &= ~(1U << 10);  // disable falling
       EXTI->RTSR |=  (1U << 10);
    // 6) Enable EXTI15_10 IRQ (covers lines 10–15)
    NVIC_SetPriority(EXTI15_10_IRQn, 1);
    NVIC_EnableIRQ(EXTI15_10_IRQn);
    __enable_irq();
}
