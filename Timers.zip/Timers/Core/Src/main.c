#include <stdio.h>
#include "main.h"


void initialize() {
	uart_init();
	led_init();
	tim2_1hz_init();
	pc13_exti_init();
	pa1_exti_init();
	pa2_exti_init();
	pa10_exti_init();

	//led_on();

}


int main(void) {
	initialize();
	while(1) {

		//printf("hie\r\n");


	}
	return (0);
}


static void exti_callback(void)
{
    printf("BTN Pressed...\n\r");
    led_toggle();
}


void EXTI15_10_IRQHandler(void) {
    if((EXTI->PR & LINE13)!=0)
    {
        /*Clear PR flag*/
        EXTI->PR |=LINE13;
        //Do something...
        exti_callback();
    }
    if (EXTI->PR & (1U << 10)) {
        EXTI->PR = (1U << 10);
        exti_callback();
    }
}


// Example ISR for PA1/PA2
void EXTI1_IRQHandler(void)
{
    if (EXTI->PR & (1U << 1)) {
        EXTI->PR = (1U << 1);    // clear pending bit
        exti_callback();
    }
}

void EXTI2_IRQHandler(void)
{
    if (EXTI->PR & (1U << 2)) {
        EXTI->PR = (1U << 2);
        // USER CODE
        exti_callback();
    }
}

