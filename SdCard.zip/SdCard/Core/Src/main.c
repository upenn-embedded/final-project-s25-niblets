/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : main.c
 * @brief          : Main program body
 ******************************************************************************
 * @attention
 *
 * Copyright (c) 2025 STMicroelectronics.
 * All rights reserved.
 *
 * This software is licensed under terms that can be found in the LICENSE file
 * in the root directory of this software component.
 * If no LICENSE file comes with this software, it is provided AS-IS.
 *
 ******************************************************************************
 */

#include "main.h"
#include "fatfs.h"

I2S_HandleTypeDef hi2s2;
SPI_HandleTypeDef hspi1;
SPI_HandleTypeDef hspi3;
UART_HandleTypeDef huart2;
DMA_HandleTypeDef hdma_spi2_tx;

int16_t samples[32000];

TCHAR readBuf[90000];

FATFS FatFs;
FIL fil;
FRESULT fres;
UINT br;
DWORD chunkSize;

char   chunkID[4];

typedef enum {
	UNKNOWN,
	HALF_COMPLETED,
	FULL_COMPLETED
} CallBack_Result_t;

CallBack_Result_t callback_result = UNKNOWN;

void SystemClock_Config(void);
static void MX_I2S2_Init(void);
static void MX_SPI3_Init(void);
static void MX_DMA_Init(void);
static void gpio_clock_enable(void);
static void MX_GPIO_I2S2_Init(void);

void HAL_I2S_TxCpltCallback(I2S_HandleTypeDef *hi2s);
void HAL_I2S_TxHalfCpltCallback(I2S_HandleTypeDef *hi2s);

bool play = false;
uint16_t txData;
int txIndex = 0;

uint32_t fread_size     = 0;
uint32_t recording_size = 0;
uint32_t played_size    = 0;


void initialize(void) {
	HAL_Init();
	setSysClockTo160MHz();
	gpio_clock_enable();
	MX_DMA_Init();
	__HAL_DMA_ENABLE_IT(&hdma_spi2_tx, DMA_IT_HT);
	__HAL_DMA_ENABLE_IT(&hdma_spi2_tx, DMA_IT_TC);
	led_init();
	uart_init();
	MX_GPIO_I2S2_Init();
	MX_SPI3_Init();
	MX_I2S2_Init();
	MX_FATFS_Init();
	delay_ms(1000);
	printf("\r\n~ Nibble Pod starting ~\r\n\r\n");
}

int main(void)
{
  initialize();

   fres = f_mount(&FatFs, "", 1); //1=mount now
   if (fres != FR_OK) {
 	printf("f_mount error (%i)\r\n", fres);
 	while(1);
   }

   DWORD free_clusters, free_sectors, total_sectors;
   FATFS* getFreeFs;
   fres = f_getfree("", &free_clusters, &getFreeFs);
   if (fres != FR_OK) {
 	printf("f_getfree error (%i)\r\n", fres);
 	while(1);
   }


   total_sectors = (getFreeFs->n_fatent - 2) * getFreeFs->csize;
   free_sectors = free_clusters * getFreeFs->csize;
   printf("SD card stats:\r\n%10lu KiB total drive space.\r\n%10lu KiB available.\r\n", total_sectors / 2, free_sectors / 2);

   fres = f_open(&fil, "billy.wav", FA_READ);
   if (fres != FR_OK) {
 	printf("f_open error (%i)\r\n", fres);
 	while(1);
   }

   FILINFO finfo;
   if (f_stat("billy.wav", &finfo) == FR_OK) {
       printf("billy.wav is %lu bytes long\r\n", (unsigned long)finfo.fsize);
   } else {
       printf("Failed to stat file\n");
   }

   f_lseek(&fil, 12);

   while (1) {
       // read 4-byte ID + 4-byte size
       f_read(&fil, chunkID, 4, &br);
       f_read(&fil, &chunkSize, 4, &br);
       if (br != 4) {
           printf("Unexpected EOF while scanning chunks\r\n");
           break;
       }

       if (memcmp(chunkID, "data", 4) == 0) {
           // found it!
           printf("Found “data” chunk at offset %lu, size = %lu bytes\r\n",
                  (unsigned long)f_tell(&fil) - 4,  // position of size field
                  (unsigned long)chunkSize);
           break;
       }

       // skip over this entire chunk (size may be odd—RFC says pad to even)
       f_lseek(&fil, f_tell(&fil) + chunkSize + (chunkSize & 1));
   }

   recording_size = chunkSize / 2;

   f_read(&fil,samples,64000,(UINT *) fread_size);

   printf("opened the wav and the first 640000 bytes file\r\n");

   HAL_I2S_Transmit_DMA(&hi2s2,(uint16_t *) samples, 32000);

   while (1) {


	   if(callback_result == HALF_COMPLETED)
	  	  {
	  		  f_read(&fil, samples, 32000, (UINT *)fread_size);
	  		  callback_result = UNKNOWN;
	  	  }

	   if(callback_result == FULL_COMPLETED)
	  	  {
	  		  f_read(&fil, &samples[16000], 32000, (UINT *)fread_size);
	  		  callback_result = UNKNOWN;
	  	  }

	  	  if(played_size >= recording_size)
	  	  {
	  		  HAL_I2S_DMAStop(&hi2s2);
	  	  }

//	   led_toggle();
//	   delay_ms(1000);

   }
   f_close(&fil);
}


void HAL_I2S_TxHalfCpltCallback(I2S_HandleTypeDef *hi2s)
{
	led_on();
	callback_result = HALF_COMPLETED;
}
void HAL_I2S_TxCpltCallback(I2S_HandleTypeDef *hi2s)
{	led_off();
	callback_result = FULL_COMPLETED;
	played_size += 32000;
}

static void MX_I2S2_Init(void)
{
 hi2s2.Instance = SPI2;
 hi2s2.Init.Mode = I2S_MODE_MASTER_TX;
 hi2s2.Init.Standard = I2S_STANDARD_PHILIPS;
 hi2s2.Init.DataFormat = I2S_DATAFORMAT_16B;
 hi2s2.Init.MCLKOutput = I2S_MCLKOUTPUT_ENABLE;
 hi2s2.Init.AudioFreq = I2S_AUDIOFREQ_16K;
 hi2s2.Init.CPOL = I2S_CPOL_LOW;
 hi2s2.Init.ClockSource = I2S_CLOCK_PLL;
 hi2s2.Init.FullDuplexMode = I2S_FULLDUPLEXMODE_DISABLE;
 if (HAL_I2S_Init(&hi2s2) != HAL_OK)
 {
   Error_Handler();
 }
}

static void MX_DMA_Init(void)
{

  /* DMA controller clock enable */
  __HAL_RCC_DMA1_CLK_ENABLE();
  HAL_NVIC_SetPriority(DMA1_Stream4_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(DMA1_Stream4_IRQn);

}
static void MX_SPI3_Init(void)
{
 hspi3.Instance = SPI3;
 hspi3.Init.Mode = SPI_MODE_MASTER;
 hspi3.Init.Direction = SPI_DIRECTION_2LINES;
 hspi3.Init.DataSize = SPI_DATASIZE_8BIT;
 hspi3.Init.CLKPolarity = SPI_POLARITY_LOW;
 hspi3.Init.CLKPhase = SPI_PHASE_1EDGE;
 hspi3.Init.NSS = SPI_NSS_SOFT;
 hspi3.Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_256;
 hspi3.Init.FirstBit = SPI_FIRSTBIT_MSB;
 hspi3.Init.TIMode = SPI_TIMODE_DISABLE;
 hspi3.Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
 hspi3.Init.CRCPolynomial = 10;
 if (HAL_SPI_Init(&hspi3) != HAL_OK)
 {
   Error_Handler();
 }
}

static void gpio_clock_enable(void)
{
	RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
	RCC->AHB1ENR |= RCC_AHB1ENR_GPIOBEN;
	RCC->AHB1ENR |=RCC_AHB1ENR_GPIOCEN;
}

static void MX_GPIO_I2S2_Init(void)
{
   // Enable the GPIO banks for PB12/13/15 and PC3
   __HAL_RCC_GPIOB_CLK_ENABLE();
   __HAL_RCC_GPIOC_CLK_ENABLE();
   GPIO_InitTypeDef gp = {0};
   gp.Mode      = GPIO_MODE_AF_PP;
   gp.Pull      = GPIO_NOPULL;
   gp.Speed     = GPIO_SPEED_FREQ_VERY_HIGH;
   gp.Alternate = GPIO_AF5_SPI2;
   // PB12=SCK, PB13=MCLK (if needed), PB15=SD
   gp.Pin = GPIO_PIN_12|GPIO_PIN_13|GPIO_PIN_15;
   HAL_GPIO_Init(GPIOB, &gp);
   // PC3 = WS (word‑select / LRCLK)
   gp.Pin = GPIO_PIN_3;
   HAL_GPIO_Init(GPIOC, &gp);
}
void Error_Handler(void)
{
 __disable_irq();
 while (1)
 {
 }
}
#ifdef  USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{}
#endif
