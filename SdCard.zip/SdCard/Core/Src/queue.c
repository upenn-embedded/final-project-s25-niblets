/*
 * queue.c
 *
 *  Created on: Apr 17, 2025
 *      Author: banele
 */


#include "queue.h"

MyCircularQueue* myCircularQueueCreate(uint8_t k) {
    MyCircularQueue* queue = (MyCircularQueue*)malloc(sizeof(MyCircularQueue));
    queue->front = 0;
    queue->rear = -1;
    queue->size = 0;
    queue->capacity = k;
    return queue;
}

bool myCircularQueueEnQueue(MyCircularQueue* obj, uint8_t value) {
    if (obj->size == obj->capacity) return false;  // full
    obj->rear = (obj->rear + 1) % obj->capacity;
    obj->data[obj->rear] = value;
    obj->size++;
    return true;
}

bool myCircularQueueDeQueue(MyCircularQueue* obj) {
    if (obj->size == 0) return false;  // empty
    obj->front = (obj->front + 1) % obj->capacity;
    obj->size--;
    return true;
}

int myCircularQueueFront(MyCircularQueue* obj) {
    return obj->size == 0 ? -1 : obj->data[obj->front];
}

int myCircularQueueRear(MyCircularQueue* obj) {
    return obj->size == 0 ? -1 : obj->data[obj->rear];
}

bool myCircularQueueIsEmpty(MyCircularQueue* obj) {
    return obj->size == 0;
}

bool myCircularQueueIsFull(MyCircularQueue* obj) {
    return obj->size == obj->capacity;
}

void myCircularQueueInit(MyCircularQueue* q, uint8_t* buffer, int logical_capacity) {
    q->data = buffer;
    q->front = 0;
    q->rear = -1;
    q->size = 0;
    q->capacity = logical_capacity;
}
