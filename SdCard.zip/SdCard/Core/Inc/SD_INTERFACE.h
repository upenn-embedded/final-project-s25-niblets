/*
 * SD_INTERFACE.h
 *
 *  Created on: Apr 18, 2025
 *      Author: banele
 */

#ifndef INC_SD_INTERFACE_H_
#define INC_SD_INTERFACE_H_

#include "ff.h"

#define ARTIST_LEN 32
#define NAME_LEN 128
#define MAX_FILES 64

typedef struct SongEntry {
    char artist[ARTIST_LEN];
    char filename[NAME_LEN];
    uint32_t length;
} SongEntry;

extern SongEntry song_list[MAX_FILES];
extern uint16_t file_count;


#endif /* INC_SD_INTERFACE_H_ */
