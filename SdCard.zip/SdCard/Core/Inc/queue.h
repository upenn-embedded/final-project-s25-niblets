/*
 * queue.h
 *
 *  Created on: Apr 17, 2025
 *      Author: banele
 */

#ifndef INC_QUEUE_H_
#define INC_QUEUE_H_
#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>

typedef struct {
    uint8_t * data; // fixed-size array
    int front;          // index of front element
    int rear;           // index of rear element
    int size;           // current number of elements
    int capacity;       // logical size (<= 2000)
} MyCircularQueue;

MyCircularQueue* myCircularQueueCreate(uint8_t k);
bool myCircularQueueEnQueue(MyCircularQueue* obj, uint8_t value);
bool myCircularQueueDeQueue(MyCircularQueue* obj);
int myCircularQueueFront(MyCircularQueue* obj);
int myCircularQueueRear(MyCircularQueue* obj);
bool myCircularQueueIsEmpty(MyCircularQueue* obj);
bool myCircularQueueIsFull(MyCircularQueue* obj);
void myCircularQueueInit(MyCircularQueue* q, uint8_t* buffer, int logical_capacity);
#endif /* INC_QUEUE_H_ */
